# Visual Music — Android project

A minimal offline music-player starter project for Android 10+.

## Current features
- Scans local audio files through Android MediaStore.
- Displays one alphabetically sorted list, without folder grouping.
- Plays local audio using AndroidX Media3 / ExoPlayer.
- MediaSessionService supports background playback and system media controls.
- Minimal white interface with a bottom mini-player.
- Basic sound presets: Flat, Pop, Rock and Bass Boost, subject to device audio-effect support.
- App icon and launcher label.

## Build an APK online with GitHub Actions
This project includes `.github/workflows/build-apk.yml`. It builds a debug APK in GitHub's cloud runner, so you do not need Android Studio on your phone.

1. Create or sign in to a GitHub account.
2. Create a **new public or private repository** named `VisualMusic`.
3. Upload the contents of this project ZIP to the repository (upload the files inside the ZIP, not the ZIP itself).
4. Open the repository's **Actions** tab.
5. Select **Build Visual Music APK**.
6. Tap **Run workflow** (or push to the `main` branch).
7. Wait for the workflow to finish successfully.
8. Open the completed workflow run, scroll to **Artifacts**, and download `Visual-Music-debug-apk`.
9. Extract the downloaded artifact ZIP. It contains `app-debug.apk`.
10. Open the APK on your Android phone and allow installation from that source if Android asks.

GitHub Actions uses Java 17 and Gradle 8.9. The Android Gradle Plugin downloads the required Android build tools and SDK during the build.

## Build locally
Open the project folder in Android Studio, use JDK 17, install Android SDK Platform 35, sync Gradle, then run `assembleDebug`.

## Important notes
- This is a source project; it is **not yet a compiled or device-tested APK**.
- The online workflow creates a debug APK, suitable for personal testing. A signed release APK can be configured later.
- Android 13+ uses the `READ_MEDIA_AUDIO` permission. Android 10–12 uses the legacy external-storage audio permission.
- Equalizer, bass boost and virtualizer support varies by device, Android version and audio route. Some audio effects may be unavailable or ignored by the phone.
- The current version is a starter build. A full Now Playing screen, album artwork, seek bar, next/previous controls and a graphical multi-band equalizer are planned enhancements.
