package com.visualmusic.player

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture

class MainActivity : AppCompatActivity() {
    private val requestCode = 41
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private val songs = mutableListOf<Song>()
    private lateinit var list: ListView
    private lateinit var miniTitle: TextView
    private lateinit var playButton: Button
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.WHITE
        window.navigationBarColor = android.graphics.Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        buildUi()
        if (hasAudioPermission()) loadSongs() else requestAudioPermission()
        connectPlayer()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFFFFFFF.toInt())
            setPadding(dp(22), dp(20), dp(22), dp(10))
        }
        val heading = TextView(this).apply {
            text = "Songs"
            textSize = 32f
            setTextColor(0xFF171717.toInt())
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        }
        root.addView(heading)
        val subtitle = TextView(this).apply {
            text = "YOUR MUSIC LIBRARY"
            textSize = 10f
            letterSpacing = 0.18f
            setTextColor(0xFF999999.toInt())
            setPadding(0, dp(5), 0, dp(18))
        }
        root.addView(subtitle)
        list = ListView(this).apply {
            divider = null
            setBackgroundColor(0xFFFFFFFF.toInt())
            setPadding(0, 0, 0, dp(8))
            isVerticalScrollBarEnabled = false
        }
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_2, android.R.id.text1, mutableListOf())
        list.adapter = adapter
        list.setOnItemClickListener { _, _, position, _ -> playSong(position) }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))

        val divider = View(this).apply { setBackgroundColor(0xFFEAEAEA.toInt()) }
        root.addView(divider, LinearLayout.LayoutParams(-1, dp(1)))
        val mini = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(4))
        }
        val textCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        miniTitle = TextView(this).apply {
            text = "No song playing"
            textSize = 14f
            setTextColor(0xFF222222.toInt())
            maxLines = 1
        }
        val artist = TextView(this).apply {
            text = "Choose a song from your library"
            textSize = 11f
            setTextColor(0xFF999999.toInt())
        }
        textCol.addView(miniTitle)
        textCol.addView(artist)
        mini.addView(textCol, LinearLayout.LayoutParams(0, -2, 1f))
        playButton = Button(this).apply {
            text = "▶"
            textSize = 18f
            setTextColor(0xFF222222.toInt())
            setBackgroundColor(android.graphics.Color.TRANSPARENT)
            setOnClickListener {
                controller?.let {
                    if (it.isPlaying) it.pause() else it.play()
                    updatePlayButton()
                }
            }
        }
        mini.addView(playButton)
        val soundButton = Button(this).apply {
            text = "♫"
            textSize = 18f
            setTextColor(0xFF222222.toInt())
            setBackgroundColor(android.graphics.Color.TRANSPARENT)
            setOnClickListener { showSoundMenu() }
        }
        mini.addView(soundButton)
        root.addView(mini)
        setContentView(root)
    }

    private fun loadSongs() {
        songs.clear()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        val cursor: Cursor? = contentResolver.query(collection, projection, selection, null, sort)
        cursor?.use {
            val idCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            while (it.moveToNext()) {
                val id = it.getLong(idCol)
                val uri = android.content.ContentUris.withAppendedId(collection, id)
                val title = it.getString(titleCol) ?: "Unknown title"
                val artist = it.getString(artistCol)?.takeUnless { name -> name == "<unknown>" } ?: "Unknown artist"
                songs.add(Song(id, title, artist, uri))
            }
        }
        adapter.clear()
        adapter.addAll(songs.map { "${it.title}\n${it.artist}" })
        adapter.notifyDataSetChanged()
        list.adapter = object : ArrayAdapter<Song>(this, android.R.layout.simple_list_item_2, android.R.id.text1, songs) {
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
                val row = super.getView(position, convertView, parent)
                val title = row.findViewById<TextView>(android.R.id.text1)
                val sub = row.findViewById<TextView>(android.R.id.text2)
                title.text = getItem(position)?.title
                title.textSize = 14f
                title.setTextColor(0xFF202020.toInt())
                sub.text = getItem(position)?.artist
                sub.textSize = 11f
                sub.setTextColor(0xFF999999.toInt())
                row.setPadding(0, dp(9), 0, dp(9))
                return row
            }
        }
    }

    private fun playSong(position: Int) {
        val c = controller ?: return
        val items = songs.map { song ->
            MediaItem.Builder()
                .setUri(song.uri)
                .setMediaMetadata(MediaMetadata.Builder().setTitle(song.title).setArtist(song.artist).build())
                .build()
        }
        c.setMediaItems(items, position, 0L)
        c.prepare()
        c.play()
        miniTitle.text = songs[position].title
        updatePlayButton()
    }

    private fun connectPlayer() {
        val token = SessionToken(this, ComponentName(this, MusicService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try {
                controller = controllerFuture?.get()
                controller?.addListener(object : androidx.media3.common.Player.Listener {
                    override fun onIsPlayingChanged(isPlaying: Boolean) = updatePlayButton()
                    override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
                        miniTitle.text = mediaMetadata.title?.toString() ?: "Visual Music"
                    }
                })
            } catch (_: Exception) { }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun updatePlayButton() {
        playButton.text = if (controller?.isPlaying == true) "Ⅱ" else "▶"
    }

    private fun showSoundMenu() {
        val options = arrayOf("Flat / Normal", "Pop", "Rock", "Bass Boost")
        android.app.AlertDialog.Builder(this)
            .setTitle("Sound effects")
            .setItems(options) { _, which ->
                val action = when (which) {
                    1 -> MusicService.ACTION_SOUND_POP
                    2 -> MusicService.ACTION_SOUND_ROCK
                    3 -> MusicService.ACTION_SOUND_BASS
                    else -> MusicService.ACTION_SOUND_OFF
                }
                startService(Intent(this, MusicService::class.java).setAction(action))
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun hasAudioPermission(): Boolean {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        return ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestAudioPermission() {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        ActivityCompat.requestPermissions(this, arrayOf(permission), requestCode)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == this.requestCode && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) loadSongs()
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
        super.onDestroy()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
