package com.visualmusic.player

import android.content.Intent
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

class MusicService : MediaSessionService() {
    private var player: ExoPlayer? = null
    private var mediaSession: MediaSession? = null
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null

    override fun onCreate() {
        super.onCreate()
        val exo = ExoPlayer.Builder(this).build()
        exo.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                .build(), true
        )
        player = exo
        mediaSession = MediaSession.Builder(this, exo).build()
        try {
            val sessionId = exo.audioSessionId
            equalizer = Equalizer(0, sessionId).apply { enabled = true }
            bassBoost = BassBoost(0, sessionId).apply { enabled = true }
            virtualizer = Virtualizer(0, sessionId).apply { enabled = false }
        } catch (_: Exception) { }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_SOUND_OFF -> setSound(0)
            ACTION_SOUND_POP -> setSound(1)
            ACTION_SOUND_ROCK -> setSound(2)
            ACTION_SOUND_BASS -> setSound(3)
        }
        return super.onStartCommand(intent, flags, startId)
    }

    private fun setSound(mode: Int) {
        try {
            equalizer?.let { eq ->
                val count = eq.numberOfBands.toInt()
                val range = eq.bandLevelRange
                val low = range[0].toInt()
                val high = range[1].toInt()
                for (i in 0 until count) {
                    val level = when (mode) {
                        1 -> if (i < count / 2) high / 3 else high / 5
                        2 -> if (i == 0 || i == count - 1) high / 2 else high / 4
                        3 -> if (i < count / 3) high / 2 else low / 8
                        else -> 0
                    }.coerceIn(low, high)
                    eq.setBandLevel(i.toShort(), level.toShort())
                }
            }
            bassBoost?.setStrength(if (mode == 3) 850.toShort() else 350.toShort())
            virtualizer?.let { it.enabled = mode == 2 }
        } catch (_: Exception) { }
    }

    override fun onDestroy() {
        equalizer?.release()
        bassBoost?.release()
        virtualizer?.release()
        mediaSession?.release()
        player?.release()
        player = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_SOUND_OFF = "com.visualmusic.SOUND_OFF"
        const val ACTION_SOUND_POP = "com.visualmusic.SOUND_POP"
        const val ACTION_SOUND_ROCK = "com.visualmusic.SOUND_ROCK"
        const val ACTION_SOUND_BASS = "com.visualmusic.SOUND_BASS"
    }
}
